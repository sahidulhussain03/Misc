# SmartSupport AI: Downloadable AI Development Kit

This is an **instruction and prompt kit**, not a finished chatbot. It includes 1 global instruction file, 9 technology-specific instructions, 16 sequential phase prompts, and a target project skeleton.

## Use
1. Open this folder in VS Code with a coding assistant that supports repository instructions and prompt files.
2. Read `.github/copilot-instructions.md`.
3. Run `.github/prompts/00-project-roadmap.prompt.md`, then `01-learn-rag.prompt.md`, then continue in numeric order.
4. At each phase, review generated code, run tests, and capture evidence before continuing.
5. Check that your IDE supports the prompt file frontmatter and path-specific `applyTo` syntax; support varies by tool/version.

## Stack
Python, FastAPI, OpenAI, LangChain, LangGraph, Qdrant, Angular, Docker Compose.

## Assignment
Seven implementation steps and an 8–12-page PDF technical report with architecture diagram, interface screenshot, code snippets, actual test results and references.

## Important
The `backend/` and `frontend/` directories are placeholders. Initialize them with tooling in Phase 02. The fictional knowledge base is created in Phase 03. Do not place real credentials in the repository. The assignment mentions Streamlit; this kit uses the requested Angular alternative, which should be approved if Streamlit is mandatory.
