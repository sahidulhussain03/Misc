---
description: Produce assignment report
---
# Produce assignment report

Read `.github/copilot-instructions.md` and all applicable path-specific instructions. Inspect the current repository before changing anything.

## Task
Collect actual code/config/versions/results/screenshots. Draft 8–12-page PDF-ready report: executive summary, architecture, implementation, testing, results, appendix. Include architecture diagram, UI screenshot, 10–15-line code snippets, 3–5 actual conversations, citations. Flag missing evidence.

## Required output
1. Beginner-friendly explanation and design choices.
2. Relevant project tree, files to create/modify, and dependencies.
3. Complete working code with paths and commands when implementation is requested.
4. Tests, expected output, failure handling, and acceptance checklist.
5. Evidence and notes to preserve for the academic report.

Do only this phase. Do not move to the next phase without confirmation. Verify official documentation for version-sensitive APIs; report uncertainty honestly.
