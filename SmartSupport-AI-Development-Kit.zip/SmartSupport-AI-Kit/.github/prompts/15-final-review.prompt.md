---
description: Audit completion
---
# Audit completion

Read `.github/copilot-instructions.md` and all applicable path-specific instructions. Inspect the current repository before changing anything.

## Task
Review architecture, security, Python, API, LangGraph, Qdrant, Angular, tests, Docker, all seven implementation steps and six report sections. List critical/important/optional issues, verified evidence, and minimal fixes; do not invent test passes.

## Required output
1. Beginner-friendly explanation and design choices.
2. Relevant project tree, files to create/modify, and dependencies.
3. Complete working code with paths and commands when implementation is requested.
4. Tests, expected output, failure handling, and acceptance checklist.
5. Evidence and notes to preserve for the academic report.

Do only this phase. Do not move to the next phase without confirmation. Verify official documentation for version-sensitive APIs; report uncertainty honestly.
