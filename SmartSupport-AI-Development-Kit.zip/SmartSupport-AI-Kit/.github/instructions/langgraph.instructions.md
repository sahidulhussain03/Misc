---
applyTo: "backend/app/graph/**/*.py"
---
# Langgraph instructions

Typed StateGraph with validation, retrieval, evidence check, answer/fallback, END; small testable nodes; conditional edges; thread-scoped checkpointer; memory is not Qdrant; document in-memory persistence limitations.

Explain decisions and verify changes with appropriate tests. Follow repository-wide instructions.
