---
applyTo: "backend/app/rag/**/*.py,backend/app/ingestion/**/*.py"
---
# Rag instructions

Preserve source metadata and chunk IDs; configurable chunking; OpenAI embeddings and chat; grounded context-only company claims; cite actual retrieved sources; abstain when insufficient; evaluate retrieval separately from generation.

Explain decisions and verify changes with appropriate tests. Follow repository-wide instructions.
