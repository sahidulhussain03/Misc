---
applyTo: "backend/app/api/**/*.py,backend/app/main.py,backend/app/services/**/*.py"
---
# Fastapi instructions

Thin routers, Pydantic schemas, dependency injection, POST /api/chat, POST /api/conversations, GET /api/health, explicit CORS, request limits, safe errors, OpenAPI and endpoint tests.

Explain decisions and verify changes with appropriate tests. Follow repository-wide instructions.
