---
applyTo: "backend/tests/**/*.py,evaluation/**/*.py,frontend/src/**/*.spec.ts"
---
# Testing instructions

Deterministic tests; mock paid APIs for unit tests; separate integration tests; fixed labeled question set; Recall@K, relevance, correctness, groundedness, abstention and latency; real before/after results only.

Explain decisions and verify changes with appropriate tests. Follow repository-wide instructions.
