---
applyTo: "backend/**/*.py"
---
# Python instructions

Type hints, small focused functions, Ruff, pytest, validated environment settings, explicit exceptions, structured safe logs, mocked unit tests; never block async event loop with sync I/O.

Explain decisions and verify changes with appropriate tests. Follow repository-wide instructions.
