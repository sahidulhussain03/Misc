---
applyTo: "backend/app/vectorstore/**/*.py,backend/scripts/**/*.py"
---
# Qdrant instructions

Local Qdrant via Docker; collection vector size matches embedding dimensions; cosine distance; stable point IDs, idempotent indexing, payload metadata, configurable top-k, empty-result handling, integration tests.

Explain decisions and verify changes with appropriate tests. Follow repository-wide instructions.
