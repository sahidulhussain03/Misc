---
applyTo: "frontend/src/**/*.ts,frontend/src/**/*.html,frontend/src/**/*.css,frontend/src/**/*.scss"
---
# Angular instructions

Angular standalone components, strict TS, HttpClient service, typed API contracts, signals where useful, accessible responsive chat, safe text rendering, loading/error states, citation display; no secrets in browser.

Explain decisions and verify changes with appropriate tests. Follow repository-wide instructions.
