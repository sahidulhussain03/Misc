---
applyTo: "docs/**/*.md,README.md"
---
# Documentation instructions

Maintain real implementation evidence, versions, diagrams, screenshots, snippets and citations. Report 8–12 pages: executive summary, architecture, implementation, testing, results, appendix. Never fabricate outcomes.

Explain decisions and verify changes with appropriate tests. Follow repository-wide instructions.
