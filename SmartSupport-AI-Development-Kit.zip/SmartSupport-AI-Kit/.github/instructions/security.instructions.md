---
applyTo: "**"
---
# Security instructions

Never commit secrets; validate input; limit payloads; explicit CORS; treat retrieval as untrusted; no prompt injection compliance; redact logs; document missing production authentication, rate limits and retention controls.

Explain decisions and verify changes with appropriate tests. Follow repository-wide instructions.
